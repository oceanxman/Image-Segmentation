data1 = [trainAndtest(10),trainAndtest(50),trainAndtest(100),trainAndtest(150),trainAndtest(200),trainAndtest(250),trainAndtest(300),trainAndtest(350),trainAndtest(400),trainAndtest(450),trainAndtest(500)];
data2 = [trainAndtest(100),trainAndtest([100, 100]),trainAndtest([100,100,100]),trainAndtest([100,100,100,100])];
data3 = [trainAndtest(100),trainAndtest([50, 50]),trainAndtest([40,30,30]),trainAndtest([25,25,25,25])];

data1
data = [data2;data3]