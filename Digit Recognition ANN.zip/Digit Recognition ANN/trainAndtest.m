function[hitPercent] = trainAndtest(layerSz)

%clc;
%clear;
%close all;

%layerSz = 100;

image = loadMNISTImages('training_set'); 
labels = loadMNISTLabels('training_label');


labels(labels==0) = 10;
labels = dummyvar(labels);
labels = labels';


net = patternnet(layerSz);

net = train(net, image, labels);

%view(net);


image1 = loadMNISTImages('test_set'); 
labels1 = loadMNISTLabels('test_label');

labels1(labels1==0) = 10;
labels1 = dummyvar(labels1);
labels1 = labels1';

%y = net(image1);
%perf = perform(net,labels1,y)
%classes = vec2ind(y);

guess = net(image1);
guess_label = (guess == max(guess));

tally_label = labels1(guess_label);
tally = sum(tally_label);

hitPercent = tally/10000;



end