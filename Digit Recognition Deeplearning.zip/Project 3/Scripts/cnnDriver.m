for k = 1:14
    cnn_fun(k,1,25)
end
for k = 1:5
    cnn_fun(7,k,25)
end
for k = 20:40
    cnn_fun(7,1,k)
end
