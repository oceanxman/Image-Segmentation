function [acc, p1,p2,p3] = cnn_fun(p1,p2,p3)

digitDatatsetPath = sprintf('C:\\Users\\Ethan\\Documents\\MATLAB\\MNIST_dataset');

imds = imageDatastore(digitDatatsetPath, 'IncludeSubfolders',true,'LabelSource','foldernames');

numTrainFiles = 750;

[imdsTrain, imdsValidation] = splitEachLabel(imds,numTrainFiles,'randomize');

inputSize = [28 28 1];
numClasses = 10;

%p1 = 5;
%p2 = 2;
%p3 = 25;

%p4 = 5;
%p5 = 1;
%p6 = 32;

p4 = p1+1;
p5 = p2+1;
p6 = p3+5;

%p7 = 7;
%p8 = 1;
%p9 = 16;

p7 = p4+1;
p8 = p5+1;
p9 = p6+5;


covLayer1 = [convolution2dLayer([p1,p1], p3, 'Stride', [p2,p2], 'Padding', 'same')
    batchNormalizationLayer
    reluLayer
    
    ];
covLayer2 = [convolution2dLayer([p4,p4], p6, 'Stride', [p5,p5], 'Padding', 'same')
    batchNormalizationLayer
    reluLayer
    
    ];
covLayer3 = [convolution2dLayer([p7,p7], p9, 'Stride', [p8,p8], 'Padding', 'same')
    batchNormalizationLayer
    reluLayer
    
    ];


layers = [imageInputLayer(inputSize)
covLayer1
covLayer2
covLayer3
fullyConnectedLayer(10)
fullyConnectedLayer(10)
softmaxLayer
classificationLayer
];

%,'Plots','training-progress'

options = trainingOptions ('sgdm','MaxEpochs',15,'ValidationData',imdsValidation,'ValidationFrequency',30,'Verbose',false);


net = trainNetwork(imdsTrain,layers,options);

guess = classify(net,imds);
labels = imds.Labels;

tally_labels = guess == labels;

tally = sum(tally_labels);

acc = tally/60000;



end