function [] = segmentImg(imgFileName, k)

img = double(imread(imgFileName));

[row, col, color] = size(img);

data =  reshape(img,col*row ,3);

%FCM fucntion and options
options = [2.0, 100, 1e-100, 0];
[center, U] = fcm(data, k, options);

[~,groups] = max(U,[],1);
groups1 = center(groups,:,:);

imgOut = reshape(groups1, row, col ,color);

area = sum(img(:));
area;
header = sprintf('Orignal\n%d Pixels  ', area);
figure(1);
subplot(1,k+2,1), imshow(img/225);
title(header)

    

i=0;
while(i<k)
    i=i+1;
    
    G = center(i,:);
    indx(:,:,1) =  G(1,1) ~= imgOut(:,:,1);
    indx(:,:,2) =  G(1,2) ~= imgOut(:,:,2);
    indx(:,:,3) =  G(1,3) ~= imgOut(:,:,3);
    img(indx) = 0;
    
    area = (img ~= 0);
    areaPx = sum(area(:));
    
    lead = sprintf('%d Pixels  ', areaPx);
    
    figure(1);
    subplot(1,k+2,i+1), imshow(img/225);
    title(lead);
    hold on;
    
    img = double(imread(imgFileName));
    
end
hold off;
















end